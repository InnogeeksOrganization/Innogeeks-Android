package com.example.monuments

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
        val chandra: Button = findViewById(R.id.chandraBtn)
        val jantar: Button = findViewById(R.id.jantarBtn)
        val citypalace: Button = findViewById(R.id.citypalaceBtn)

        chandra.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://jaipurtourism.co.in/chandra-mahal-jaipur"))
            startActivity(intent)
        }
        jantar.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://asi.payumoney.com/quick/jnm"))
            startActivity(intent)

        }
        citypalace.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://thecitypalacejaipur.com/book-ticket"))
            startActivity(intent)
        }
    }
}