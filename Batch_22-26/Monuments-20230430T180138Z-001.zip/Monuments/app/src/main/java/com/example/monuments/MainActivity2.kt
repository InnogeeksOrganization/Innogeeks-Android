package com.example.monuments

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val fortBtn: Button = findViewById(R.id.fortBtn)
        val akbarBtn: Button = findViewById(R.id.akbarTombBtn)
        val mehtabBtn: Button = findViewById(R.id.mehtabBtn)

        fortBtn.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://asi.payumoney.com/quick/agf"))
            startActivity(intent)
        }
        akbarBtn.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://asi.payumoney.com/"))
            startActivity(intent)

        }
        mehtabBtn.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://asi.payumoney.com/quick/meh"))
            startActivity(intent)
        }
    }
}