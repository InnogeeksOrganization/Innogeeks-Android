package com.example.monuments

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        val church: Button = findViewById(R.id.churchBtn)
        val birla: Button = findViewById(R.id.birlaBtn)
        val kalighat: Button = findViewById(R.id.kalighatBtn)

        church.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://kolkatatourism.travel/st-paul-s-cathedral-kolkata"))
            startActivity(intent)
        }
        birla.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.hyderabadtourism.travel/birla-planetarium-hyderabad"))
            startActivity(intent)

        }
        kalighat.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.darshanbooking.com/darshan-timings/kalighat-kali-temple-darshan-aarti-bhog-opening-time-pooja-timings.html"))
            startActivity(intent)
        }
    }
}